package com.highcom.common;

import com.highcom.config.RedisConfig;
import com.highcom.config.RedisConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import redis.clients.jedis.JedisPool;

import javax.annotation.PostConstruct;
import java.util.Set;

@EnableScheduling
@SpringBootApplication
public class DemoApplication {



    private static JedisPool jedisPool;
    @Autowired
    private RedisConfig redisConfig;

    @PostConstruct
    public void init() {
        jedisPool = redisConfig.redisPoolFactory();
    }


    @Scheduled(cron = "0/5 * * * * ?")
    public void job1(){
        Set<String> set = jedisPool.getResource().sdiff(RedisConstant.SETMEAL_PIC_RESOURCES, RedisConstant.SETMEAL_PIC_DB_RESOURCES);
        if (set != null){
            for (String picName : set) {
                QiniuUtils.deleteFileFromQiniu(picName);
                jedisPool.getResource().srem(RedisConstant.SETMEAL_PIC_RESOURCES,picName);
                System.out.println("自定义任务执行，清理垃圾图片："+picName);
            }
        }

    }

}
